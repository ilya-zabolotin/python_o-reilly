from setuptools import setup 
setup (
	name='vsearch',
	version='1.0',
	description='The HeadFirst Python Search Tools',
	author='Ilya Zabolotin',
	author_email='mcclenn@rambler.ru',
	url='headfirstlabs.com',
	py_modules=['vsearch'],
)